<?php
$CONF = array();
	$CONF["host"] = "127.0.0.1";
	$CONF["user"] = "root";
	$CONF["pass"] = "root";
	$CONF["name"] = "capital2";
	?>